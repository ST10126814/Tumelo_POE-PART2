﻿using System.Collections.Generic;
using System.Data.SqlClient;

namespace demo_part2.Models
{
    public class ReviewClaims
    {
        public List<string> Email { get; set; } = new List<string>();
        public List<string> Module { get; set; } = new List<string>();
        public List<int> Id { get; set; } = new List<int>();
        public List<int> Hours { get; set; } = new List<int>();
        public List<decimal> Rate { get; set; } = new List<decimal>();
        public List<string> Note { get; set; } = new List<string>();
        public List<decimal> Total { get; set; } = new List<decimal>();
        public List<string> Status { get; set; } = new List<string>();
        public List<string> Filename { get; set; } = new List<string>();

        private readonly connection connect = new connection();

        public ReviewClaims()
        {
            LoadClaims();
        }

        private void LoadClaims()
        {
            string emails = GetEmails();

            try
            {
                using (SqlConnection connection = new SqlConnection(connect.connecting()))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT * FROM claiming WHERE email = @Email", connection))
                    {
                        command.Parameters.AddWithValue("@Email", emails);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Email.Add(reader["email"].ToString());
                                Module.Add(reader["module"].ToString());
                                Id.Add((int)reader["id"]);
                                Hours.Add((int)reader["hours"]);
                                Rate.Add((decimal)reader["rate"]);
                                Note.Add(reader["note"].ToString());
                                Total.Add((decimal)reader["total"]);
                                Status.Add(reader["status"].ToString());
                                Filename.Add(reader["files"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            }
        }

        // Other methods remain the same...
        public void ApproveClaim(int claimId)
        {
            UpdateClaimStatus(claimId, "Approved");
        }

        public void DeclineClaim(int claimId)
        {
            UpdateClaimStatus(claimId, "Declined");
        }

        private void UpdateClaimStatus(int claimId, string status)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connect.connecting()))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand("UPDATE claiming SET status = @Status WHERE id = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Status", status);
                        command.Parameters.AddWithValue("@Id", claimId);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            }
        }

        public void DisplayClaims()
        {
            for (int i = 0; i < Id.Count; i++)
            {
                Console.WriteLine($"ID: {Id[i]}, Email: {Email[i]}, Module: {Module[i]}, Hours: {Hours[i]}, Rate: {Rate[i]}, Total: {Total[i]}, Status: {Status[i]}, Note: {Note[i]}, Filename: {Filename[i]}");
            }
        }

        private string GetEmails()
        {
            // Logic to get the emails (returning a placeholder for now)
            return "example@example.com"; // Replace with actual logic to retrieve the user's email
        }
    }
}
 














