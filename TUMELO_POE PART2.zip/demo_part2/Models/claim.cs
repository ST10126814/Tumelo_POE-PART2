﻿using System.Data.SqlClient;

namespace demo_part2.Models
{
    public class claim
    {
        public string user_email { get; set; }
        public string user_id { get; set; }
        public string hours_worked { get; set; }
        public string hour_rate { get; set; }
        public string description { get; set; }

        public string status { get; set; }

        //connection
        connection connect = new connection();

        public string insert_claim(string module_name, string hours_worked, string rate, string note, string filename)
        {
            //temp message
            string message = "";

            string user_ID = get_id();
            string user_EMAIL = get_email();


            string total = "" + (int.Parse(hours_worked) * int.Parse(rate));
            string query = "insert into claiming values('" + user_EMAIL + "', '" + module_name + "', '" + user_ID + "','" + hours_worked + "','" + rate + "','" + note + "','none','none','" + total + "','" + filename + "','pending');";
            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    connects.Open();
                    using (SqlCommand done = new SqlCommand(query, connects))
                    {
                        done.ExecuteNonQuery();
                        message = "done";
                    }
                    connects.Close();
                }
            }
            catch (IOException error)
            {
                message = error.Message;
            }


            return message;
        }
        //get email
        public string get_email()
        {
            //hold email variable
            string hold_email = "";

            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    connects.Open();

                    using (SqlCommand prepare = new SqlCommand("select * from active", connects))
                    {

                        using (SqlDataReader getEMAIL = prepare.ExecuteReader())
                        {
                            if (getEMAIL.HasRows)
                            {
                                //check all gets and set
                                while (getEMAIL.Read())
                                {
                                    //then get it
                                    hold_email = getEMAIL["email"].ToString();
                                }

                            }
                            getEMAIL.Close();
                        }
                    }

                    connects.Close();
                    ;
                }
            }
            catch (IOException error)
            {
                Console.WriteLine(error.Message);
                hold_email = error.Message;
            }

            return hold_email;
        }


        //get id
        public string get_id()
        {
            //hold id variable
            string hold_id = "";

            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    connects.Open();

                    using (SqlCommand prepare = new SqlCommand("select * from active", connects))
                    {

                        using (SqlDataReader getID = prepare.ExecuteReader())
                        {
                            if (getID.HasRows)
                            {
                                //check all gets and set
                                while (getID.Read())
                                {
                                    //then get it
                                    hold_id = getID["id"].ToString();
                                }

                            }
                            getID.Close();
                        }
                    }

                    connects.Close();
                    ;
                }
            }
            catch (IOException error)
            {
                Console.WriteLine(error.Message);
                hold_id = error.Message;
            }

            return hold_id;
        }



    }
}
