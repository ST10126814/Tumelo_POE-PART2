﻿using System.Data.SqlClient;

namespace demo_part2.Models
{
    public class check_login
    {
        public string Email { get; set; }
        public string Role { get; set; }
        public string Password { get; set; }

        //get the connection string
        connection connect = new connection();

        //method to check the user 
        public string login_user(string Email, string Role, string Password)
        {
            //temp variable message
            string message = "";
            Console.WriteLine(Email + " and " + Password);

            try
            {
                //connect and open
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {
                    //open connection
                    connects.Open();

                    //query
                    string query = "select * from users where email='" + Email + "' and password= '" + Password + "';";

                    //prepare to execute
                    using(SqlCommand prepare = new SqlCommand(query, connects))
                    {
                        //read the data
                        using (SqlDataReader find_user = prepare.ExecuteReader())
                        {
                            //then check if the user is found
                            if(find_user.HasRows) 
                            {
                                message = "found";
                             }
                            else
                            {
                                message = "not";
                            }
                        }

                    }
                    connects.Close ();
                    if(message == "found")
                    {
                        update_active(Email);
                    }
                
                }


            }
            catch(IOException error_db)
            {
                //return error
                message = error_db.Message;
            }

            return message;
        
        }
        
        //update active field
        public void update_active(string Email)
        {
            try
            {
                using (SqlConnection connects = new SqlConnection(connect.connecting()))
                {

                    connects.Open();

                    string query = "update active set email = '" + Email + "'";

                    using (SqlCommand done = new SqlCommand(query, connects))
                    {
                        done.ExecuteNonQuery();
                    }

                    connects.Close();
                }
            }
            catch(IOException error)
            {
                Console.WriteLine("Error " + error.Message);
            }
        }

    }
}
