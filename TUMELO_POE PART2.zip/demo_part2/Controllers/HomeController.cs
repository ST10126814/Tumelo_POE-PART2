using demo_part2.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Diagnostics;

namespace demo_part2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {

            //check the connection
            try
            {
                //get the connection string from the connection class
                connection conn = new connection();

                //then check
                using (SqlConnection connect = new SqlConnection(conn.connecting()))
                {
                    //open connection 
                    connect.Open();
                    Console.WriteLine("Connected");
                    connect.Close();
                }
            }
            catch(IOException error)
            {
                //error message
                Console.WriteLine("Error : " + error.Message);
            }

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        //http post for the register
        //From the register form
        [HttpPost]
        public IActionResult Register_user(register add_user)
        {
            //collect users value
            string name = add_user.Username;
            string email = add_user.Email;
            string role = add_user.Role;
            string password = add_user.Password;

            //check if all are collected
            //Console.WriteLine("Name: " + name + "\nEmail " + email + "Role: " + role);
            
            //pass all values into insert method
            string message = add_user.insert_user(name, email, role, password);

            //check if inserted
            if (message == "done")
            {
                //redirect
                return RedirectToAction("Login", "Home");
            }
            else
            {
                //track error output
                Console.Write(message);

                //redirect
                return RedirectToAction("Index", "Home");
            }
           
        }

        //for login page
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Dashboard()
        {
            return View();
        }
        //checking the user login page
        [HttpPost]
        public IActionResult Login_user(check_login user)
        {
            //then assign
            string email = user.Email;
            string role = user.Role;
            string password = user.Password;

            string message = user.login_user(email, role, password);

            if (message == "found")
            {
                Console.WriteLine(message);
                return RedirectToAction("Dashboard", "Home");
            }
            else
            {
                Console.WriteLine(message);
                return RedirectToAction("Login", "Home");
            }
        }

        [HttpPost]
        public IActionResult claim_sub(IFormFile file, claim insert)
        {
            //assign
           
            string module_name = insert.user_email;
            string hours_work = insert.hours_worked;
            string hour_rate = insert.hour_rate;
            string description = insert.description;

            //file info
            string filename = "no file";
            if (file != null && file.Length > 0)
            {
                // Get the file name
                 filename = Path.GetFileName(file.FileName);

                // Define the folder path (pdf folder)
                string folderPath = Path.Combine(Directory.GetCurrentDirectory(),
               "wwwroot/pdf");

                // Ensure the pdf folder exists
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                // Define the full path where the file will be saved
                string filePath = Path.Combine(folderPath, filename);

                // Save the file to the specified path
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                    
                }
            }

            string message = insert.insert_claim( module_name, hours_work, hour_rate, description, filename);


            if(message == "done")
            {
                Console.WriteLine(message);
                return RedirectToAction("Dashboard", "Home");
            }

            else
            {
                Console.WriteLine(message);
                return RedirectToAction("Dashbaord", "Home");           }
        }



        public IActionResult view_claims()

        {
            get_claims collect = new get_claims();
            return View(collect);
         }


            public ActionResult Claims()
            {
                var reviewClaims = new ReviewClaims();
                var claimsList = new List<get_claims>();

                for (int i = 0; i < reviewClaims.Id.Count; i++)
                {
                    claimsList.Add(new get_claims
                    {
                        






                    });
                }

                return View(claimsList);
            }

            [HttpPost]
            public ActionResult Approve(int id)
            {
                var reviewClaims = new ReviewClaims();
                reviewClaims.ApproveClaim(id);
                return RedirectToAction("Claims");
            }

            [HttpPost]
            public ActionResult Decline(int id)
            {
                var reviewClaims = new ReviewClaims();
                reviewClaims.DeclineClaim(id);
                return RedirectToAction("Claims");
            }
        }
    }





